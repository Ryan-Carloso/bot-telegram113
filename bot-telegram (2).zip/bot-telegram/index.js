const { Telegraf } = require("telegraf");
var moment = require("moment");  

const bot = new Telegraf("");

const array = ["🧤", "🧤", "🧤", "🧤", "🧤"];

let arrayIcons = [];
let message_id = null; // armazena o message_id da mensagem enviada
let messagem;

function enviar() {
   if (message_id) {
     messagem = messagem.replace(
       "🟢🟢 Entrada Confirmada 🟢🟢",
       "🔵🔵 Entrada Finalizada 🔵🔵"
     );
     messagem = messagem.replace("Tentativas: 3", "");
     messagem = messagem.replace("Valido até as", "Finalizada ");
     bot.telegram.editMessageText("@penaltylop", message_id, null, messagem);
   }
  
  arrayIcons = [];
  arrayIcons = array.slice();
  arrayIcons[Math.floor(Math.random() * (4 + 1))] = "⚽️";
  console.log("array.slice()", array);

  let validityTime = moment().add("minutes", 5).format("LT");
  messagem = `
🟢🟢 Entrada Confirmada 🟢🟢 

🎯Entrada:
________
|${arrayIcons[0]}${arrayIcons[1]}${arrayIcons[2]}|
|${arrayIcons[3]}🧍🏻${arrayIcons[4]}|

🎲 Tentativas: 3
📲 𝙁𝘼𝘾̧𝘼 𝘾𝘼𝘿𝘼𝙎𝙏𝙍𝙊 𝘼𝙌𝙐𝙄: https://br4bet.com/register/betpay
⏱ Valido até as ${validityTime}`;


  bot.telegram.sendMessage("@penaltylop", messagem)
    .then((msg) => {
      message_id = msg.message_id; // armazena o message_id da mensagem enviada
    });
  
  
  let timeDiff = moment(validityTime, "LT").diff(moment(), "milliseconds");
  setTimeout(enviar, timeDiff); // aguarda até que o horário de validade seja atingido antes de chamar a função novamente
}



enviar();